# To Use

>[!NOTE]
> First: `npm install`
> Then: `npm run dev`
